<?php
require_once 'koneksi.php';
session_start();
require_once 'auth.php';
checkAccess('admin');

// Ambil user_id dari sesi login
$user_id = $_SESSION['user_id'];

// Ambil data profil dari database
$stmt = $koneksi->prepare("SELECT * FROM profiles WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$profile = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Profil Admin - MJ SPORT</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-[linear-gradient(to_bottom,_#123458_62%,_#030303_100%)] text-white font-sans">

<!-- Tombol Kembali -->
<div class="fixed top-6 right-6 z-50 flex items-center gap-4">
  <button onclick="history.back()" class="flex items-center gap-2 text-base bg-white bg-opacity-20 hover:bg-opacity-30 backdrop-blur-md px-5 py-2.5 rounded-full text-white shadow-lg transition">
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" class="w-5 h-5">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
    </svg>
    Kembali
  </button>
  <a href="profiladmin.php" class="bg-white bg-opacity-20 hover:bg-opacity-30 backdrop-blur-md p-2.5 rounded-full shadow-lg transition">
    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.121 17.804A13.937 13.937 0 0112 15c2.828 0 5.433.877 7.879 2.363M15 10a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
  </a>
</div>

<div class="flex">
  <!-- Sidebar -->
  <aside class="w-64 min-h-screen bg-[#0d2236] p-6 flex flex-col items-center sticky top-0">
    <div class="w-40 h-40 mb-6">
      <img src="LogoMJ.png" alt="MJ Sport Logo" class="w-full h-full object-contain">
    </div>
    <h1 class="text-2xl font-extrabold tracking-widest mb-10">MJ SPORT</h1>
    <nav class="space-y-4 w-full">
      <a href="profiltoko-admin.php" class="flex items-center gap-3 hover:bg-white hover:text-[#123458] py-2 px-4 rounded-lg transition">👥 Profil Perusahaan</a>
      <a href="aktivitastoko-admin.php" class="flex items-center gap-3 hover:bg-white hover:text-[#123458] py-2 px-4 rounded-lg transition">🏪 Aktivitas Toko</a>
      <a href="daftarproduk-admin.php" class="flex items-center gap-3 hover:bg-white hover:text-[#123458] py-2 px-4 rounded-lg transition">📦 Data Produk</a>
      <a href="tampilanfeedbacktoko-admin.php" class="flex items-center gap-3 hover:bg-white hover:text-[#123458] py-2 px-4 rounded-lg transition">💬 Feedback Pengunjung</a>
      <a href="logout.php" class="flex items-center gap-3 hover:bg-white hover:text-[#123458] py-2 px-4 rounded-lg transition">⏻ Logout</a>
    </nav>
  </aside>

  <!-- Konten Profil -->
  <main class="flex-1 p-10">
    <div class="max-w-3xl mx-auto bg-white bg-opacity-10 backdrop-blur-md rounded-3xl p-8 shadow-xl space-y-8">
      <div class="bg-[#0d2236] rounded-xl p-6 text-center">
        <h2 class="text-xl font-bold mb-4">Biodata</h2>
        <div class="w-28 h-28 mx-auto rounded-full overflow-hidden border-4 border-white">
          <img src="<?= htmlspecialchars($profile['photo'] ?? 'fotoprofiladmin.jpg') ?>" alt="Foto Profil" class="w-full h-full object-cover">
        </div>
      </div>

      <div class="bg-gradient-to-r from-[#0d2236] to-[#134a8e] rounded-xl p-6 space-y-4">
        <div class="flex justify-between items-center">
          <h3 class="text-lg font-semibold">Informasi Personal</h3>
          <button onclick="window.location.href='editprofil-admin.php';" class="flex items-center gap-1 bg-white text-[#123458] px-3 py-1 rounded-md text-sm hover:bg-opacity-80 transition">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5h2m-1 0v14m-7-7h14" />
            </svg> Edit
          </button>
        </div>

        <div class="grid grid-cols-1 gap-4 text-sm">
          <p><strong>Nama Lengkap:</strong> <?= htmlspecialchars($profile['full_name'] ?? '-') ?></p>
          <p><strong>Tempat, Tanggal Lahir:</strong> <?= htmlspecialchars($profile['birth_place_date'] ?? '-') ?></p>
          <p><strong>Jenis Kelamin:</strong> <?= htmlspecialchars($profile['gender'] ?? '-') ?></p>
          <p><strong>Alamat:</strong> <?= htmlspecialchars($profile['address'] ?? '-') ?></p>
        </div>

        <hr class="border-white/30 my-4">

        <h3 class="text-lg font-semibold">Informasi Tambahan</h3>
        <div class="grid grid-cols-1 gap-4 text-sm">
          <p><strong>Pekerjaan:</strong> <?= htmlspecialchars($profile['occupation'] ?? '-') ?></p>
          <p><strong>Minat:</strong> <?= htmlspecialchars($profile['interest'] ?? '-') ?></p>
          <p><strong>Media Sosial:</strong> <?= htmlspecialchars($profile['social_media'] ?? '-') ?></p>
        </div>
      </div>
    </div>
  </main>
</div>
</body>
</html>
